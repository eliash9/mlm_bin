
<strong>Copyright &copy; 2015 - <?php echo date('Y'); ?> <a target='_BLANK' href="https://members.phpmu.com"> MLM Binary System</a>.</strong> All rights reserved.