    <p class='sidebar-title'><span class='glyphicon glyphicon-remove'></span> <strong>Maaf, Login Gagal!</strong></p>
    
<center style='padding:50px'>
<style>
.lupa {
	width:50%;
}
</style>
<h2>Gagal Login !!!</h2>
Password yang dimasukkan salah. Silakan coba lagi (pastikan caps lock tidak aktif).<br>
Anda Lupa Password? <a data-dismiss="modal" aria-hidden="true" data-toggle='modal' href='#lupass' data-target='#lupass' title="Lupa Password Members">Reset Password Disini.</a><br>

<br><br>
</center>