<p class='sidebar-title'><span class='glyphicon glyphicon-ok'></span> <strong>Success Melakukan Pemesanan!</strong></p>
<center style='padding:50px'>
<style>
.lupa { width:50%; }
</style>
<div class='alert alert-success'>Success Order!</div>
Permohonan untuk pembelian kode aktivasi Success...<br>
Kami telah mengirimkan detail pesanan anda ke <b class='btn btn-xs btn-success'><?php echo $email; ?></b><br>
Pesanan anda segera diproses dan PIN aktivasi akan dikirimkan via email/sms, <br> 
Silahkan Menunggu info dari kami, salam,..<br>
<br><br>
</center>